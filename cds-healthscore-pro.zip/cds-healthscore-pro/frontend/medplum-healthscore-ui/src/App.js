import React, { useState } from "react";
import { MedplumProvider, LoginButton, useMedplum } from "@medplum/react";
import { MedplumClient } from "@medplum/core";
import { Line } from "react-chartjs-2";
import { Chart, registerables } from "chart.js";
import { motion } from "framer-motion";
import { HeartPulse, AlertTriangle, Activity } from "lucide-react";
Chart.register(...registerables);

const medplum = new MedplumClient({
  baseUrl: "https://api.medplum.com",
  clientId: process.env.REACT_APP_MEDPLUM_CLIENT_ID || "YOUR_CLIENT_ID",
  redirectUri: window.location.origin + "/"
});

function Dashboard() {
  const [patientId, setPatientId] = useState("");
  const [card, setCard] = useState(null);
  const [trend, setTrend] = useState(null);
  const [loading, setLoading] = useState(false);
  const { client, accessToken } = useMedplum();

  const fetchScore = async () => {
    if (!patientId) return alert("Enter Patient id (e.g., Patient/123)");
    setLoading(true);
    try {
      const res = await fetch("/cds-services/health-score", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        // include access token if available
        ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {})
        ,
        body: JSON.stringify({
          hook: "patient-view",
          hookInstance: "inst-" + Date.now(),
          context: { patientId }
        })
      });
      const data = await res.json();
      setCard(data.cards?.[0] || null);

      // fetch medplum observations for trend using medplum client if available
      let obsData;
      if (client) {
        obsData = await client.read({ resourceType: "Observation", id: "" }).catch(()=>null);
      }
      // fallback to public API call (may be rate limited)
      const obsRes = await fetch(`https://api.medplum.com/fhir/R4/Observation?subject=${patientId}&_count=50`);
      const obsJson = await obsRes.json();
      const hr = obsJson.entry?.filter(e => /heart|pulse/i.test((e.resource.code?.text||"")));
      if (hr && hr.length) {
        const labels = hr.slice(0,10).map((e,i)=> new Date(e.resource.effectiveDateTime||Date.now()-i*3600000).toLocaleString());
        const values = hr.slice(0,10).map(e=> e.resource.valueQuantity?.value || null);
        setTrend({ labels: labels.reverse(), values: values.reverse() });
      } else setTrend(null);
    } catch (err) {
      console.error(err);
      alert("Failed to fetch. Make sure backend is reachable.");
    } finally {
      setLoading(false);
    }
  };

  const getIcon = (indicator) => {
    if (!indicator) return <HeartPulse size={36} />;
    if (indicator === "info") return <HeartPulse size={36} color="green" />;
    if (indicator === "warning") return <AlertTriangle size={36} color="orange" />;
    return <Activity size={36} color="red" />;
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <motion.div className="w-full max-w-2xl bg-white rounded-2xl shadow-lg p-6" initial={{opacity:0, y:10}} animate={{opacity:1,y:0}}>
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-2xl font-semibold">Medplum Health Score Dashboard</h1>
          <LoginButton />
        </div>

        <div className="flex gap-3 mb-4">
          <input className="flex-1 p-2 border rounded" placeholder="Patient/123" value={patientId}
            onChange={e=>setPatientId(e.target.value)} />
          <button className="px-4 py-2 bg-blue-600 text-white rounded" onClick={fetchScore} disabled={loading}>
            {loading ? "Calculating..." : "Fetch"}
          </button>
        </div>

        {card && (
          <div className="mt-4 flex gap-4 items-center">
            <div>{getIcon(card.indicator)}</div>
            <div>
              <div className="text-lg font-medium">{card.summary}</div>
              <div className="text-sm text-gray-600">{card.detail}</div>
            </div>
            <div className="ml-auto">
              <a className="text-sm text-blue-600" href={`https://app.medplum.com/Patient/${patientId}`} target="_blank" rel="noreferrer">Open in Medplum</a>
            </div>
          </div>
        )}

        {trend && (
          <div className="mt-6">
            <h3 className="font-medium mb-2">Recent Heart Rate Trend</h3>
            <Line data={{
              labels: trend.labels,
              datasets: [{ label: "Heart Rate", data: trend.values, tension: 0.3 }]
            }} />
          </div>
        )}

        <div className="mt-6 text-sm text-gray-500">
          Note: OAuth requires you to set REACT_APP_MEDPLUM_CLIENT_ID and register redirect URI in Medplum client settings.
        </div>
      </motion.div>
    </div>
  );
}

export default function AppWrapper() {
  return (
    <MedplumProvider medplum={medplum} >
      <Dashboard />
    </MedplumProvider>
  );
}
