package com.example.cdshealthscore.controller;

import com.example.cdshealthscore.model.CdsCard;
import com.example.cdshealthscore.model.CdsResponse;
import com.example.cdshealthscore.service.MedplumService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cds-services")
public class HealthScoreCdsController {

    @Autowired
    private MedplumService medplumService;

    @PostMapping("/health-score")
    public CdsResponse getHealthScore(@RequestBody String hookRequest) {
        String patientId = medplumService.extractPatientId(hookRequest);
        double score = medplumService.calculateHealthScore(patientId);

        String summary = String.format("Patient Health Score: %.1f", score);
        String indicator = (score > 80) ? "info" : (score > 50 ? "warning" : "critical");

        CdsCard card = new CdsCard("health-score-card", summary, indicator,
                "Score computed using recent Observations from Medplum. Click to open patient record.");

        return new CdsResponse(new CdsCard[]{card});
    }
}
