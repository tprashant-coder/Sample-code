package com.example.cdshealthscore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CdsHealthScoreApplication {
    public static void main(String[] args) {
        SpringApplication.run(CdsHealthScoreApplication.class, args);
    }
}
