package com.example.cdshealthscore.model;

public class CdsCard {
    private String uuid;
    private String summary;
    private String indicator;
    private String detail;

    public CdsCard() {}

    public CdsCard(String uuid, String summary, String indicator, String detail) {
        this.uuid = uuid;
        this.summary = summary;
        this.indicator = indicator;
        this.detail = detail;
    }

    public String getUuid() { return uuid; }
    public String getSummary() { return summary; }
    public String getIndicator() { return indicator; }
    public String getDetail() { return detail; }

    public void setUuid(String uuid) { this.uuid = uuid; }
    public void setSummary(String summary) { this.summary = summary; }
    public void setIndicator(String indicator) { this.indicator = indicator; }
    public void setDetail(String detail) { this.detail = detail; }
}
