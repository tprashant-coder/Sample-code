package com.example.cdshealthscore.model;

public class CdsResponse {
    private CdsCard[] cards;

    public CdsResponse() {}

    public CdsResponse(CdsCard[] cards) {
        this.cards = cards;
    }

    public CdsCard[] getCards() {
        return cards;
    }

    public void setCards(CdsCard[] cards) {
        this.cards = cards;
    }
}
