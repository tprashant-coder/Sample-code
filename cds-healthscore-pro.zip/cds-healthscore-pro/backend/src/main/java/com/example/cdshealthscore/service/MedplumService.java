package com.example.cdshealthscore.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class MedplumService {

    @Value("${medplum.api.base-url}")
    private String medplumBaseUrl;

    @Value("${medplum.api.token:}")
    private String accessToken;

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    public String extractPatientId(String hookRequestJson) {
        try {
            JsonNode root = objectMapper.readTree(hookRequestJson);
            String patientId = root.path("context").path("patientId").asText();
            if (patientId == null || patientId.isEmpty()) {
                patientId = root.path("context").path("patient").asText();
            }
            return patientId;
        } catch (Exception e) {
            return null;
        }
    }

    public double calculateHealthScore(String patientId) {
        if (patientId == null || patientId.isEmpty()) {
            return 50.0;
        }
        try {
            String url = medplumBaseUrl + "/Observation?subject=" + patientId + "&_count=100";
            HttpHeaders headers = new HttpHeaders();
            if (accessToken != null && !accessToken.isEmpty()) {
                headers.set(HttpHeaders.AUTHORIZATION, "Bearer " + accessToken);
            }
            headers.set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
            HttpEntity<String> entity = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
            JsonNode root = objectMapper.readTree(response.getBody());

            double rawScore = 100.0;
            int modifiers = 0;

            for (JsonNode entry : root.path("entry")) {
                JsonNode obs = entry.path("resource");
                String code = obs.path("code").path("text").asText("");
                double value = obs.path("valueQuantity").path("value").asDouble(Double.NaN);

                String codeLower = code.toLowerCase();
                if (!Double.isNaN(value)) {
                    if (codeLower.contains("heart") || codeLower.contains("pulse") || codeLower.contains("heart rate")) {
                        if (value > 100 || value < 60) rawScore -= 12;
                        modifiers++;
                    } else if (codeLower.contains("blood pressure") || codeLower.contains("systolic") || codeLower.contains("diastolic")) {
                        if (value > 140 || value < 90) rawScore -= 15;
                        modifiers++;
                    } else if (codeLower.contains("bmi")) {
                        if (value > 30 || value < 18.5) rawScore -= 10;
                        modifiers++;
                    } else if (codeLower.contains("respiratory")) {
                        if (value > 20 || value < 12) rawScore -= 8;
                        modifiers++;
                    }
                }
            }

            if (modifiers == 0) return 75.0;
            double score = rawScore / Math.max(1, modifiers);
            if (score < 0) score = 0;
            return score;
        } catch (Exception e) {
            e.printStackTrace();
            return 60.0;
        }
    }
}
