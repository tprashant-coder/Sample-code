# cds-healthscore-pro

## Overview
Complete project with:
- Spring Boot backend exposing CDS Hook `/cds-services/health-score`
- React frontend with Medplum OAuth login + trend chart
- Docker & docker-compose for local deployment
- GitHub Actions workflow to build and produce artifact

## Setup

### Required
- Java 17+, Maven
- Node 18+, npm
- Docker (for docker-compose)
- Medplum account and an OAuth client (create at https://app.medplum.com/admin/clients)
  - Set the redirect URI to `http://localhost:3000/` in your Medplum client.

### Local (without Docker)
1. Backend:
   ```bash
   cd backend
   mvn spring-boot:run
   ```
2. Frontend:
   ```bash
   cd frontend/medplum-healthscore-ui
   cp .env.example .env
   # Edit .env to set REACT_APP_MEDPLUM_CLIENT_ID
   npm install
   npm start
   ```

### With Docker
1. Create `.env` at project root:
   ```
   REACT_APP_MEDPLUM_CLIENT_ID=your_medplum_client_id_here
   ```
2. Run:
   ```
   docker-compose up --build
   ```
3. Frontend available at http://localhost:3000 and backend at http://localhost:8080

## Notes
- The frontend uses `@medplum/react` LoginButton which implements OAuth redirect flow — it will be operational once you set `REACT_APP_MEDPLUM_CLIENT_ID` and register redirect URI in Medplum.
- For production, secure backend endpoints, use HTTPS, and manage secrets properly.
